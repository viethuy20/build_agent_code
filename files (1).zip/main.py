"""
Orchestrator MVP v0.1

Flow:
  1. Đọc tasks/<TASK_ID>/task.json + plan.md (Codex đã tạo sẵn 2 file này
     trong Antigravity, bạn chỉ cần review trước khi chạy).
  2. Tạo git branch agent/<TASK_ID> (cô lập khỏi main).
  3. Ghép prompt từ plan + task, gọi Antigravity CLI (agy) headless để
     implement.
  4. Orchestrator TỰ chạy lại test_commands (không tin agy tự báo cáo).
  5. PASS -> commit lên branch. FAIL -> dừng, giữ log, KHÔNG commit,
     không tự động retry.

Cách chạy:
  python orchestrator/main.py --task tasks/TASK-001 --repo /path/to/your/repo

Yêu cầu trước khi chạy:
  - Đã cài Antigravity CLI và chạy `agy` một lần thủ công để đăng nhập.
  - Repo đích (--repo) là git repo sạch (không có uncommitted changes).
  - KHÔNG có credential production thật (AWS/DB) trong environment khi
    chạy orchestrator này, vì agy chạy với --dangerously-skip-permissions.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys

import agy_worker
import git_manager
import test_runner
from logger import TaskLogger


def load_task(task_dir: pathlib.Path) -> dict:
    task_json_path = task_dir / "task.json"
    plan_md_path = task_dir / "plan.md"

    if not task_json_path.exists():
        raise FileNotFoundError(f"Không tìm thấy {task_json_path}")
    if not plan_md_path.exists():
        raise FileNotFoundError(f"Không tìm thấy {plan_md_path}")

    task = json.loads(task_json_path.read_text(encoding="utf-8"))
    task["_plan_md"] = plan_md_path.read_text(encoding="utf-8")
    return task


def build_prompt(task: dict) -> str:
    requirements = "\n".join(f"- {r}" for r in task.get("requirements", []))
    acceptance = "\n".join(f"- {a}" for a in task.get("acceptance_criteria", []))

    return f"""Bạn là implementation worker cho một task Data Engineering.
Không cần hỏi lại người dùng — hãy tự đọc repository hiện tại và implement
theo đúng kế hoạch dưới đây.

# Task: {task.get('title', task.get('task_id'))}

## Mô tả
{task.get('description', '')}

## Yêu cầu
{requirements}

## Tiêu chí nghiệm thu
{acceptance}

## Kế hoạch implementation (đã được duyệt trước)
{task['_plan_md']}

## Việc bạn cần làm
1. Đọc code hiện có trong repository để hiểu convention đang dùng.
2. Implement đúng theo kế hoạch ở trên, không tự ý mở rộng phạm vi.
3. Sau khi implement xong, DỪNG LẠI. Không cần tự chạy test hay tự commit
   — phần đó do hệ thống bên ngoài đảm nhiệm.
4. Không được: chạm vào credential thật, gọi API production, xoá dữ liệu,
   force-push, hoặc thay đổi file ngoài phạm vi task này.
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="DE Agent Orchestrator MVP")
    parser.add_argument("--task", required=True, help="Thư mục task, vd: tasks/TASK-001")
    parser.add_argument("--repo", required=True, help="Đường dẫn tới git repo đích")
    parser.add_argument("--base-branch", default="main", help="Branch gốc để tạo nhánh agent/")
    parser.add_argument("--timeout", type=int, default=1800, help="Timeout cho agy (giây)")
    args = parser.parse_args()

    project_root = pathlib.Path(__file__).resolve().parent.parent
    task_dir = pathlib.Path(args.task).resolve()
    repo_path = pathlib.Path(args.repo).resolve()
    logs_dir = project_root / "logs"

    task = load_task(task_dir)
    task_id = task.get("task_id", task_dir.name)

    logger = TaskLogger(task_id, logs_dir)
    logger.section(f"TASK {task_id} CREATED")
    logger.log(f"repo={repo_path}")
    logger.log(f"task_dir={task_dir}")

    try:
        # --- 1. Chuẩn bị git branch cô lập ---
        git_manager.ensure_clean_worktree(repo_path)
        branch = git_manager.create_task_branch(repo_path, task_id, args.base_branch)
        logger.log(f"BRANCH CREATED: {branch}")

        # --- 2. Gọi agy implement ---
        prompt = build_prompt(task)
        logger.log("GEMINI/AGY STARTED")
        agy_result = agy_worker.run_agy(
            prompt=prompt,
            workdir=repo_path,
            logs_dir=logs_dir,
            task_id=task_id,
            timeout_seconds=args.timeout,
        )

        if not agy_result.ok:
            logger.log("GEMINI/AGY FAILED")
            logger.log(f"REASON: {agy_result.note}")
            logger.section(f"TASK {task_id} FAILED")
            return 1

        logger.log("GEMINI/AGY FINISHED")
        if agy_result.note:
            logger.log(f"NOTE: {agy_result.note}")

        changed_files = git_manager.diff_stat(repo_path)
        logger.log(f"FILES CHANGED:\n{changed_files or '(không có thay đổi nào được ghi nhận)'}")

        if not git_manager.has_uncommitted_changes(repo_path):
            logger.log("Agy không tạo ra thay đổi nào trong repo.")
            logger.section(f"TASK {task_id} FAILED")
            return 1

        # --- 3. Orchestrator tự verify, không tin agy tự báo cáo ---
        logger.log("TEST STARTED")
        test_result = test_runner.run_tests(task.get("test_commands", []), repo_path)

        if not test_result.passed:
            logger.log("TEST FAILED")
            logger.log(f"COMMAND: {test_result.command}")
            logger.log(f"OUTPUT:\n{test_result.output}")
            logger.section(f"TASK {task_id} FAILED")
            logger.log(
                "Không commit. Code lỗi vẫn nằm trên branch "
                f"{branch} để bạn xem xét bằng tay."
            )
            return 1

        logger.log("TEST PASSED")

        # --- 4. Commit ---
        commit_message = f"[agent] {task_id}: {task.get('title', '')}"
        commit_hash = git_manager.commit_all(repo_path, commit_message)
        logger.log(f"COMMIT CREATED: {commit_hash}")
        logger.section(f"TASK {task_id} COMPLETED")
        return 0

    except (git_manager.GitError, agy_worker.AgyNotAvailable, FileNotFoundError) as exc:
        logger.log(f"ERROR: {exc}")
        logger.section(f"TASK {task_id} FAILED")
        return 1
    finally:
        logger.close()


if __name__ == "__main__":
    sys.exit(main())
