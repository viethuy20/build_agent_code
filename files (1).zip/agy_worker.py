"""
Gọi Antigravity CLI (agy) ở chế độ headless để implement code.

Vì sao không dùng Gemini CLI cũ:
Gemini CLI đã ngừng phục vụ tài khoản cá nhân (Google AI Pro/Ultra/Free) từ
18/6/2026, thay thế bằng Antigravity CLI (agy). Ta dùng agy để tận dụng
quota Google Pro sẵn có, không tốn phí API riêng.

BUG QUAN TRỌNG cần biết trước khi đọc code này:
`agy --print` / `agy -p` bị lỗi đã xác nhận trên nhiều bản: khi stdout không
phải TTY thật (tức là mọi trường hợp subprocess/pipe — chính là cách
orchestrator này gọi nó), agy chạy xong, tốn round-trip với model, exit
code = 0, nhưng KHÔNG in gì ra stdout. Không có gì phân biệt được giữa
"model trả lời rỗng" và "câu trả lời hữu ích bị nuốt mất".

Cách xử lý ở đây (2 lớp phòng thủ):
1. Bọc lệnh agy trong pseudo-TTY bằng `script -qec` (Linux) để agy tưởng
   đang chạy trong terminal thật -> lấy được output thật.
2. Nếu output vẫn rỗng, thử phục hồi từ transcript agy tự lưu trong
   ~/.gemini/antigravity-cli/conversations/ (best-effort, không đảm bảo
   100%). Nếu không phục hồi được, coi task là FAILED và ghi log rõ ràng
   thay vì âm thầm coi như thành công.

Giới hạn đã biết:
- Cách này được viết cho Linux/macOS (dùng lệnh `script`). Trên Windows cần
  cơ chế khác (ví dụ winpty) — chưa hỗ trợ trong bản này.
- --dangerously-skip-permissions cho agy tự động approve mọi tool call
  (đọc/ghi file, chạy lệnh). Vì vậy PHẢI giới hạn phạm vi bằng --add-dir
  trỏ đúng vào thư mục task, và KHÔNG được có credential thật
  (AWS, DB production...) trong environment khi orchestrator chạy.
"""

from __future__ import annotations

import dataclasses
import json
import pathlib
import re
import shutil
import subprocess
import time


class AgyNotAvailable(RuntimeError):
    pass


@dataclasses.dataclass
class AgyResult:
    ok: bool
    output: str
    raw_log_path: pathlib.Path
    note: str = ""


def _check_agy_installed() -> None:
    if shutil.which("agy") is None:
        raise AgyNotAvailable(
            "Không tìm thấy lệnh `agy` trong PATH. "
            "Cài Antigravity CLI và chạy `agy` một lần thủ công để đăng nhập "
            "trước khi dùng orchestrator này."
        )


def _strip_pty_artifacts(text: str) -> str:
    """script -qec bọc pseudo-TTY sẽ chèn \\r vào cuối dòng. Dọn sạch."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Loại bỏ các dòng banner "Script started/done" mà lệnh `script` tự thêm
    text = re.sub(r"^Script (started|done).*$", "", text, flags=re.MULTILINE)
    return text.strip()


def _try_recover_from_transcript(home: pathlib.Path, started_at: float) -> str | None:
    """Best-effort: tìm conversation mới nhất được tạo sau started_at
    và lấy nội dung trả lời cuối cùng của model.

    agy lưu lịch sử hội thoại dưới ~/.gemini/antigravity-cli/conversations/
    và ~/.gemini/antigravity-cli/brain/<id>/. Định dạng có thể thay đổi giữa
    các phiên bản, nên đây chỉ là lớp cứu hộ best-effort, không đảm bảo.
    """
    conv_dir = home / ".gemini" / "antigravity-cli" / "conversations"
    if not conv_dir.exists():
        return None

    candidates = sorted(
        conv_dir.glob("*.json*"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for path in candidates:
        if path.stat().st_mtime < started_at - 5:
            continue  # file cũ hơn lúc bắt đầu chạy, bỏ qua
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
            # Thử parse JSONL: lấy field "content" của message cuối cùng có role assistant
            last_text = None
            for line in content.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict) and obj.get("role") in ("assistant", "model"):
                    last_text = obj.get("content") or obj.get("text")
            if last_text:
                return last_text
        except OSError:
            continue
    return None


def run_agy(
    prompt: str,
    workdir: pathlib.Path,
    logs_dir: pathlib.Path,
    task_id: str,
    timeout_seconds: int = 1800,
) -> AgyResult:
    """Chạy agy headless trong workdir, trả về AgyResult.

    prompt: nội dung task + plan + yêu cầu, đã ghép sẵn ở main.py
    workdir: thư mục repo (đã checkout đúng branch agent/<task_id>)
    logs_dir: nơi ghi raw output để debug
    """
    _check_agy_installed()

    raw_log_path = logs_dir / f"{task_id}.agy.raw.log"
    workdir = workdir.resolve()

    # Ghi prompt ra file tạm để tránh vấn đề escape ký tự khi truyền qua shell
    prompt_file = logs_dir / f"{task_id}.prompt.txt"
    prompt_file.write_text(prompt, encoding="utf-8")

    # Lớp 1: bọc pseudo-TTY bằng `script -qec` để tránh bug stdout rỗng.
    # -q: quiet (không in banner riêng của script vào output cuối)
    # -e: trả về đúng exit code của lệnh con
    # -c: chạy lệnh được truyền vào
    inner_cmd = (
        f"agy --dangerously-skip-permissions "
        f"--add-dir {workdir} "
        f"--print-timeout {timeout_seconds}s "
        f"-p \"$(cat {prompt_file})\""
    )
    full_cmd = ["script", "-qec", inner_cmd, "/dev/null"]

    started_at = time.time()
    try:
        result = subprocess.run(
            full_cmd,
            cwd=workdir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds + 60,  # buffer thêm cho overhead của script/agy
        )
    except subprocess.TimeoutExpired:
        raw_log_path.write_text(
            "TIMEOUT: agy không phản hồi trong thời gian cho phép.\n",
            encoding="utf-8",
        )
        return AgyResult(
            ok=False,
            output="",
            raw_log_path=raw_log_path,
            note=f"Timeout sau {timeout_seconds}s",
        )

    raw_output = _strip_pty_artifacts(result.stdout)
    raw_log_path.write_text(
        f"exit_code={result.returncode}\n\n"
        f"--- stdout ---\n{result.stdout}\n\n"
        f"--- stderr ---\n{result.stderr}\n",
        encoding="utf-8",
    )

    if result.returncode != 0:
        return AgyResult(
            ok=False,
            output=raw_output,
            raw_log_path=raw_log_path,
            note=f"agy thoát với exit code {result.returncode}. Xem {raw_log_path}",
        )

    if raw_output:
        return AgyResult(ok=True, output=raw_output, raw_log_path=raw_log_path)

    # Lớp 2: output rỗng dù exit code = 0 -> nghi ngờ đúng bug đã biết.
    # Thử phục hồi từ transcript trước khi kết luận FAILED.
    recovered = _try_recover_from_transcript(pathlib.Path.home(), started_at)
    if recovered:
        return AgyResult(
            ok=True,
            output=recovered,
            raw_log_path=raw_log_path,
            note="Output gốc rỗng (bug agy stdout đã biết), đã phục hồi từ transcript.",
        )

    return AgyResult(
        ok=False,
        output="",
        raw_log_path=raw_log_path,
        note=(
            "agy trả về stdout rỗng dù exit code 0 và không phục hồi được "
            "transcript. Đây khớp với bug đã biết của agy khi chạy dưới "
            "subprocess. Kiểm tra: (1) `agy --version` có phải bản đã fix bug "
            "này chưa, (2) đăng nhập agy còn hợp lệ không (auth timeout cũng "
            "gây stdout rỗng), (3) xem log thô tại " + str(raw_log_path)
        ),
    )
